extends CharacterBody2D

enum State {
	IDLE,
	PATROL,
	CHASE,
	ATTACK,
	RETURN
}

@export var patrol_speed: float = 70.0
@export var chase_speed: float = 115.0
@export var attack_damage: int = 10
@export var attack_cooldown: float = 1.0

# CORREGIDO: El tipo debe ser AnimatedSprite2D, no AnimatableBody2D
@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var detectionArea: Area2D = $DetectionArea
@onready var attackArea: Area2D = $AttackArea
@onready var position_a: Marker2D = $"PositionPatrol A"
@onready var position_b: Marker2D = $"PositionPatrol B"

@onready var nav_agent: NavigationAgent2D = $NavigationAgent2D

var state: State = State.PATROL # Que empiece patrullando
var player: CharacterBody2D = null
var patrol_position: Array[Vector2] = []
var patrol_index: int = 0
var home_position: Vector2

var attack_timer: float = 0.0

func _ready() -> void:
	home_position = global_position
	
	patrol_position = [
		position_a.global_position,
		position_b.global_position
	]
	
	detectionArea.body_entered.connect(_on_detection_area_body_entered)
	detectionArea.body_exited.connect(_on_detection_area_body_exited)
	
	# Aseguramos que el área de ataque también conecte sus señales
	attackArea.body_entered.connect(_on_attack_area_body_entered)
	attackArea.body_exited.connect(_on_attack_area_body_exited)

func _physics_process(delta: float) -> void:
	# CORREGIDO: Se eliminó toda la gravedad de plataforma
	match state:
		State.PATROL:
			patrol_state()
		State.CHASE:
			chase_state()
		State.ATTACK:
			attack_state(delta)

	move_and_slide()

# --- LÓGICA DE ESTADOS ---

func patrol_state() -> void:
	sprite.play("walk") # Nombre de tu animación (según tu primera imagen)
	
	if patrol_position.is_empty(): return
	
	# El agente calcula la ruta hacia el punto de patrullaje
	var target = patrol_position[patrol_index]
	nav_agent.target_position = target 
	
	# Nos movemos hacia el siguiente punto seguro de la ruta generada
	var next_path_position = nav_agent.get_next_path_position()
	var direction = global_position.direction_to(next_path_position)
	velocity = direction * patrol_speed
	
	# Si llegamos, pasamos al siguiente punto
	if global_position.distance_to(target) < 10.0:
		patrol_index = (patrol_index + 1) % patrol_position.size()

func chase_state() -> void:
	if player != null:
		var direction = global_position.direction_to(player.global_position)
		velocity = direction * chase_speed

func attack_state(delta: float) -> void:
	# TAREA 2: Si el jugador muere, dejar de atacar
	if player != null and player.is_dead:
		player = null
		state = State.PATROL
		return

	sprite.play("attack") # Nombre de tu animación (según tu primera imagen)
	velocity = Vector2.ZERO # Se queda quieto mientras ataca
	attack_timer -= delta
	
	if attack_timer <= 0.0 and player != null:
		if player.has_method("take_damage"):
			player.take_damage(attack_damage)
			print("¡Golpe! Daño infligido: ", attack_damage)
			attack_timer = attack_cooldown

# --- SEÑALES DE VISIÓN Y ATAQUE ---

func _on_detection_area_body_entered(body: Node2D) -> void:
	if body.is_in_group("player"):
		player = body
		if state != State.ATTACK:
			state = State.CHASE

func _on_detection_area_body_exited(body: Node2D) -> void:
	if body.is_in_group("player"):
		player = null
		state = State.PATROL

func _on_attack_area_body_entered(body: Node2D) -> void:
	if body.is_in_group("player"):
		state = State.ATTACK

func _on_attack_area_body_exited(body: Node2D) -> void:
	if body.is_in_group("player"):
		# Si sale del rango de ataque pero sigue viéndolo, lo vuelve a perseguir
		if detectionArea.overlaps_body(body):
			state = State.CHASE
		else:
			state = State.PATROL
			player = null
